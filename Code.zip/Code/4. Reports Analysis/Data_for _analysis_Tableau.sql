SET search_path to 'project';

CREATE TABLE freq_donation_amount AS
(select amount2010+amount2011+amount2012+
		amount2013+amount2014+amount2015+
		amount2016 as nbr_times, count(id) as nbr_accounts
 from countamount
 group by nbr_times
);

CREATE TABLE rec_donors_amount AS
(select nbr_times, nbr_accounts
 from freq_donation_amount
 where nbr_times >= 2
);

CREATE TABLE freq_donation_meals AS
(select donmeals2006+donmeals2007+donmeals2008+
		donmeals2009+donmeals2010+donmeals2011+
		donmeals2012+donmeals2013+donmeals2014+
        donmeals2015+donmeals2016 as nbr_meals, count(id) as nbr_accounts
 from countdonationmeals
 group by nbr_meals
);

CREATE TABLE rec_donors_meals AS
(select nbr_meals, nbr_accounts
 from freq_donation_meals
 where nbr_meals >= 2
);

/*********************************************************************************/


drop table countdonationmeals;

CREATE TABLE countdonationmeals as
(SELECT id, state, count(nummeals2006) as donmeals2006,count(nummeals2007) as donmeals2007, count(nummeals2008) as donmeals2008, count(nummeals2009) as donmeals2009,
            count(nummeals2010) as donmeals2010,count(nummeals2011) as donmeals2011,count(nummeals2012) as donmeals2012,
				 count(nummeals2013) as donmeals2013,count(nummeals2014) as donmeals2014,count(nummeals2015)as donmeals2015, count(nummeals2016) as donmeals2016
FROM account
GROUP BY id,state);

drop table freq_donation_meals;

CREATE TABLE freq_donation_meals AS
(select donmeals2006+donmeals2007+donmeals2008+
		donmeals2009+donmeals2010+donmeals2011+
		donmeals2012+donmeals2013+donmeals2014+
        donmeals2015+donmeals2016 as nbr_meals, count(id) as nbr_accounts, state
 from countdonationmeals
 group by nbr_meals,state
);

drop table rec_donors_meals;

CREATE TABLE rec_donors_meals AS
(select nbr_meals, nbr_accounts,state
 from freq_donation_meals
 where nbr_meals >= 2
);

/**************************************/

drop table countamount;

CREATE TABLE countamount as
SELECT id, state, count(totalamount2010) as amount2010, count(totalamount2011) as amount2011, count(totalamount2012) as amount2012, count(totalamount2013) as amount2013, 
			count(totalamount2014) as amount2014, count(totalamount2015) as amount2015,count(totalamount2016) as amount2016
FROM account
GROUP BY id,state

drop table freq_donation_amount;

CREATE TABLE freq_donation_amount AS
(select amount2010+amount2011+amount2012+
		amount2013+amount2014+amount2015+
		amount2016 as nbr_times, count(id) as nbr_accounts, state
 from countamount
 group by nbr_times, state
);

drop table rec_donors_amount;

CREATE TABLE rec_donors_amount AS
(select nbr_times, nbr_accounts, state
 from freq_donation_amount
 where nbr_times >= 2
);

CREATE TABLE major_donor AS (
select distinct state, count(majordonor) as mj
from account
where majordonor = 'true'
group by state);

