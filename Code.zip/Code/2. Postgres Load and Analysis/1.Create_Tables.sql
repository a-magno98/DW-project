CREATE SCHEMA labo;

SET search_path TO "project";

CREATE TABLE Account
(
Number				VARCHAR      NOT NULL,
Type				VARCHAR		 NOT NULL,
SubType				VARCHAR      NOT NULL,
PostalCode			NUMERIC		 NOT NULL,
City				VARCHAR(30)  NOT NULL,
State				VARCHAR(30)	 NOT NULL,
Country				VARCHAR(30)  NOT NULL,
Id					VARCHAR		 NOT NULL,
Assigned			VARCHAR      NOT NULL,
TotalAmount		    NUMERIC		 NOT NULL,
TotalMeals			NUMERIC		 NOT NULL,
MajorDonor			BOOLEAN      NOT NULL,
NumMeals2006		NUMERIC      NOT NULL,
NumMeals2007		NUMERIC      NOT NULL,
NumMeals2008		NUMERIC      NOT NULL,
NumMeals2009		NUMERIC      NOT NULL,
NumMeals2010 		NUMERIC      NOT NULL,
NumMeals2011		NUMERIC      NOT NULL,
NumMeals2012		NUMERIC      NOT NULL,
NumMeals2013		NUMERIC      NOT NULL,
NumMeals2014		NUMERIC      NOT NULL,
NumMeals2015		NUMERIC      NOT NULL,
NumMeals2016		NUMERIC      NOT NULL,
TotalAmount2010		NUMERIC      NOT NULL,
TotalAmount2011		NUMERIC      NOT NULL,
TotalAmount2012		NUMERIC      NOT NULL,
TotalAmount2013		NUMERIC      NOT NULL,
TotalAmount2014		NUMERIC      NOT NULL,
TotalAmount2015		NUMERIC      NOT NULL,
TotalAmount2016		NUMERIC      NOT NULL
);

CREATE TABLE Opportunity
(
AccountId			VARCHAR		 NOT NULL,
CampaignId			VARCHAR		 NOT NULL,
CampaignName		VARCHAR      NOT NULL,
Frequency			VARCHAR 	 ,
Type 				VARCHAR 	 NOT NULL
);
