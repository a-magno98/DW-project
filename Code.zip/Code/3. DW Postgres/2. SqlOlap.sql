SET search_path TO 'project';

/* 1. Calculate the total of meals donated in 2011 for the following
	  attributes:
		-assigned, city of donor
		-city of donor*/
	
	SELECT assigned, city, SUM(num_meals) as TotMeals
	FROM assigned_dt A, donation_ft D, account_dt AC, year_dt Y
	WHERE Y.yearid = D.yearid
	  AND AC.accountid = D.accountid
	  AND A.assignedid = D.assignedid
	  AND year = 2011
	GROUP BY ROLLUP (assigned, city)
	
/* 2. Show for each donor and year
  -the totalamount donated
  -the ratio between the totalamount of
   the current row and the grand total
  -the ratio between the amount of the 
   current row and the grand total by state of
   the donor*/
   
	SELECT accountnumber, year, totalamount,
		totalamount/SUM(totalamount) OVER ()
				AS TotalPerc,
		totalamount/SUM(totalamount) OVER (PARTITION BY State)
				AS StatePerc
	FROM donation_ft D, year_dt Y, account_dt AC
	WHERE Y.yearid = D.yearid
	  AND AC.accountid = D.accountid
	  
/* 3. Show, for every city of donors in 2013
	  -the number of meals donated
	  -the position in the ranking*/
	  
	SELECT city, num_meals,
		   RANK() OVER (ORDER BY num_meals DESC)
		   AS Ranking
	FROM donation_ft D, account_dt ACC, year_dt Y
	WHERE  Y.yearid = D.yearid
	  AND ACC.accountid = D.accountid
	  AND year = 2013
	  
/* 4. Show, for every city of donors and year
	  -the number of meals donated
	  -the cumulative number of meals donated
	   as year go by, separately for each city */
	 
	SELECT city, year, num_meals,
		SUM(num_meals) OVER 
					(PARTITION BY city
					 ORDER BY year ASC
					 ROWS UNBOUNDED PRECEDING) AS CumulSum
	FROM donation_ft D, account_dt ACC, year_dt Y
	WHERE  Y.yearid = D.yearid
	  AND ACC.accountid = D.accountid	

/* 5. Show, for every city of donors and year
	  -the number of meals donated
	  -the average, computed on the current year
	   and the previous 2 years, separately for each city */
	
	SELECT city, year, num_meals,
		AVG(num_meals) OVER 
					(PARTITION BY city
					 ORDER BY year
					 ROWS 2 PRECEDING) AS MobileAvg
	FROM donation_ft D, account_dt ACC, year_dt Y
	WHERE  Y.yearid = D.yearid
	  AND ACC.accountid = D.accountid	
	
	