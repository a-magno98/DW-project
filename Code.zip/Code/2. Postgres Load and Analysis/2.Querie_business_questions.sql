SET search_path TO 'project';

/*change value 0 in NULL because I can use 
function COUNT for counting the recurring donors based on meals*/

ALTER TABLE Account
ALTER COLUMN nummeals2006
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2007
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2008
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2009
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2010
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2011
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2012
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2013
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2014
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2015
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2016
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN nummeals2009
DROP NOT NULL;
/***********************************/

UPDATE account
set nummeals2006 = NULL
where nummeals2006 = 0;

UPDATE account
set nummeals2007 = NULL
where nummeals2007 = 0;

UPDATE account
set nummeals2008 = NULL
where nummeals2008 = 0;

UPDATE account
set nummeals2009 = NULL
where nummeals2009 = 0;

UPDATE account
set nummeals2010 = NULL
where nummeals2010 = 0;

UPDATE account
set nummeals2011 = NULL
where nummeals2011 = 0;

UPDATE account
set nummeals2012 = NULL
where nummeals2012 = 0;

UPDATE account
set nummeals2013 = NULL
where nummeals2013 = 0;

UPDATE account
set nummeals2014 = NULL
where nummeals2014 = 0;

UPDATE account
set nummeals2015 = NULL
where nummeals2015 = 0;

UPDATE account
set nummeals2016 = NULL
where nummeals2016 = 0;*/

CREATE TABLE countdonationmeals as
SELECT id, count(nummeals2006) as donmeals2006,count(nummeals2007) as donmeals2007, count(nummeals2008) as donmeals2008, count(nummeals2009) as donmeals2009,
            count(nummeals2010) as donmeals2010,count(nummeals2011) as donmeals2011,count(nummeals2012) as donmeals2012,
				 count(nummeals2013) as donmeals2013,count(nummeals2014) as donmeals2014,count(nummeals2015)as donmeals2015, count(nummeals2016) as donmeals2016
FROM account
GROUP BY id

/*recurring donors based on how many times a person donated meals from 2006 to 2016
  if a person donated a least 2 times is considered a recurring donors*/
SELECT id
FROM countdonationmeals
WHERE donmeals2006+donmeals2007+donmeals2008+donmeals2009+donmeals2010+
	  donmeals2011+donmeals2012+donmeals2013+donmeals2014+donmeals2015+
	  donmeals2016 >=2

/**********************************************************************/
/*change value 0 in NULL because I can use 
function COUNT for counting the recurring donors based on amount*/

ALTER TABLE Account
ALTER COLUMN totalamount2010
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN totalamount2011
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN totalamount2012
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN totalamount2013
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN totalamount2014
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN totalamount2015
DROP NOT NULL;

ALTER TABLE Account
ALTER COLUMN totalamount2016
DROP NOT NULL;
/**********************************/

UPDATE account
set totalamount2010 = NULL
where totalamount2010 = 0;

UPDATE account
set totalamount2011 = NULL
where totalamount2011 = 0;

UPDATE account
set totalamount2012 = NULL
where totalamount2012 = 0;

UPDATE account
set totalamount2013 = NULL
where totalamount2013 = 0;

UPDATE account
set totalamount2014 = NULL
where totalamount2014 = 0;

UPDATE account
set totalamount2015 = NULL
where totalamount2015 = 0;

UPDATE account
set totalamount2016 = NULL
where totalamount2016 = 0;*/
	  
CREATE TABLE countamount as
SELECT id, count(totalamount2010) as amount2010, count(totalamount2011) as amount2011, count(totalamount2012) as amount2012, count(totalamount2013) as amount2013, 
			count(totalamount2014) as amount2014, count(totalamount2015) as amount2015,count(totalamount2016) as amount2016
FROM account
GROUP BY id

/*recurring donors based on how many times a person donated amount from 2010-2016
  if a person donated a least 2 times is considered a recurring donors*/
SELECT id
FROM countamount
WHERE amount2010+amount2011+amount2012+amount2013+amount2014+
		amount2015+amount2016 >=2


/*Do the giving amounts increases or decreases
  vary based on donor level*/
/* Levels
   1. 1 to 1000
   2. 1000 to 10000
   3. 10000 to 50000
   4. 50000 to 100000
   5. 100000 to 1000000
   6. 1000000 and above */

/*************************************************/

/*level_1*/

CREATE TABLE level_1 
(
	year NUMERIC,
	tot NUMERIC
);

INSERT INTO level_1 (tot) VALUES (
(SELECT SUM(totalamount2010) AS tot10
	  FROM account
	  WHERE totalamount2010 >= 1 AND totalamount2010 < 1000
	)
);

UPDATE level_1 
SET YEAR=2010
WHERE tot = ( SELECT SUM(totalamount2010) AS tot10
	  		  FROM account
	  		  WHERE totalamount2010 >= 1 AND totalamount2010 < 1000
	        );

INSERT INTO level_1 (tot) VALUES (
(SELECT SUM(totalamount2011) AS tot11
	  FROM account
	  WHERE totalamount2011 >= 1 AND totalamount2011 < 1000
	)
);

UPDATE level_1 
SET YEAR=2011
WHERE tot = ( SELECT SUM(totalamount2011) AS tot11
	  		  FROM account
	  		  WHERE totalamount2011 >= 1 AND totalamount2011 < 1000
	        );
			
INSERT INTO level_1 (tot) VALUES (
(SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 1 AND totalamount2012 < 1000
	)
);

UPDATE level_1 
SET YEAR=2012
WHERE tot = (SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 1 AND totalamount2012 < 1000
);

INSERT INTO level_1 (tot) VALUES (
(SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 1 AND totalamount2013 < 1000
	)
);

UPDATE level_1 
SET YEAR=2013
WHERE tot = (SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 1 AND totalamount2013 < 1000
);
	
INSERT INTO level_1 (tot) VALUES (
(SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 1 AND totalamount2014 < 1000
	)
);

UPDATE level_1 
SET YEAR=2014
WHERE tot = (SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 1 AND totalamount2014 < 1000
);

INSERT INTO level_1 (tot) VALUES (
(SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 1 AND totalamount2015 < 1000
	)
);

UPDATE level_1 
SET YEAR=2015
WHERE tot = (SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 1 AND totalamount2015 < 1000
);

INSERT INTO level_1 (tot) VALUES (
(SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 1 AND totalamount2016 < 1000
	)
);

UPDATE level_1 
SET YEAR=2016
WHERE tot = (SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 1 AND totalamount2016 < 1000
);


/*level_2*/
CREATE TABLE level_2 
(
	year NUMERIC,
	tot NUMERIC
);

INSERT INTO level_2 (tot) VALUES (
(SELECT SUM(totalamount2010) AS tot10
	  FROM account
	  WHERE totalamount2010 >= 1000 AND totalamount2010 < 10000
	)
);

UPDATE level_2 
SET YEAR=2010
WHERE tot = ( SELECT SUM(totalamount2010) AS tot10
	  		  FROM account
	  		  WHERE totalamount2010 >= 1000 AND totalamount2010 < 10000
	        );

INSERT INTO level_2 (tot) VALUES (
(SELECT SUM(totalamount2011) AS tot11
	  FROM account
	  WHERE totalamount2011 >= 1000 AND totalamount2011 < 10000
	)
);

UPDATE level_2 
SET YEAR=2011
WHERE tot = ( SELECT SUM(totalamount2011) AS tot11
	  		  FROM account
	  		  WHERE totalamount2011 >= 1000 AND totalamount2011 < 10000
	        );
			
INSERT INTO level_2 (tot) VALUES (
(SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 1000 AND totalamount2012 < 10000
	)
);

UPDATE level_2 
SET YEAR=2012
WHERE tot = (SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 1000 AND totalamount2012 < 10000
);

INSERT INTO level_2 (tot) VALUES (
(SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 1000 AND totalamount2013 < 10000
	)
);

UPDATE level_2 
SET YEAR=2013
WHERE tot = (SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 1000 AND totalamount2013 < 10000
);
	
INSERT INTO level_2 (tot) VALUES (
(SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 1000 AND totalamount2014 < 10000
	)
);

UPDATE level_2 
SET YEAR=2014
WHERE tot = (SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 1000 AND totalamount2014 < 10000
);

INSERT INTO level_2 (tot) VALUES (
(SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 1000 AND totalamount2015 < 10000
	)
);

UPDATE level_2 
SET YEAR=2015
WHERE tot = (SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 1000 AND totalamount2015 < 10000
);

INSERT INTO level_2 (tot) VALUES (
(SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 1000 AND totalamount2016 < 10000
	)
);

UPDATE level_2 
SET YEAR=2016
WHERE tot = (SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 1000 AND totalamount2016 < 10000
);

/*level_3*/
CREATE TABLE level_3 
(
	year NUMERIC,
	tot NUMERIC
);

INSERT INTO level_3 (tot) VALUES (
(SELECT SUM(totalamount2010) AS tot10
	  FROM account
	  WHERE totalamount2010 >= 10000 AND totalamount2010 < 50000
	)
);

UPDATE level_3 
SET YEAR=2010
WHERE tot = ( SELECT SUM(totalamount2010) AS tot10
	  		  FROM account
	  		  WHERE totalamount2010 >= 10000 AND totalamount2010 < 50000
	        );

INSERT INTO level_3 (tot) VALUES (
(SELECT SUM(totalamount2011) AS tot11
	  FROM account
	  WHERE totalamount2011 >= 10000 AND totalamount2011 < 50000
	)
);

UPDATE level_3 
SET YEAR=2011
WHERE tot = ( SELECT SUM(totalamount2011) AS tot11
	  		  FROM account
	  		  WHERE totalamount2011 >= 10000 AND totalamount2011 < 50000
	        );
			
INSERT INTO level_3 (tot) VALUES (
(SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 10000 AND totalamount2012 < 50000
	)
);

UPDATE level_3 
SET YEAR=2012
WHERE tot = (SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 10000 AND totalamount2012 < 50000
);

INSERT INTO level_3 (tot) VALUES (
(SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 10000 AND totalamount2013 < 50000
	)
);

UPDATE level_3 
SET YEAR=2013
WHERE tot = (SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 10000 AND totalamount2013 < 50000
);
	
INSERT INTO level_3 (tot) VALUES (
(SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 10000 AND totalamount2014 < 50000
	)
);

UPDATE level_3 
SET YEAR=2014
WHERE tot = (SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 10000 AND totalamount2014 < 50000
);

INSERT INTO level_3 (tot) VALUES (
(SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 10000 AND totalamount2015 < 50000
	)
);

UPDATE level_3 
SET YEAR=2015
WHERE tot = (SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 10000 AND totalamount2015 < 50000
);

INSERT INTO level_3 (tot) VALUES (
(SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 10000 AND totalamount2016 < 50000
	)
);

UPDATE level_3 
SET YEAR=2016
WHERE tot = (SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 10000 AND totalamount2016 < 50000
);

/*level_4*/
CREATE TABLE level_4 
(
	year NUMERIC,
	tot NUMERIC
);

INSERT INTO level_4 (tot) VALUES (
(SELECT SUM(totalamount2010) AS tot10
	  FROM account
	  WHERE totalamount2010 >= 50000 AND totalamount2010 < 100000
	)
);

UPDATE level_4 
SET YEAR=2010
WHERE tot = ( SELECT SUM(totalamount2010) AS tot10
	  		  FROM account
	  		  WHERE totalamount2010 >= 50000 AND totalamount2010 < 100000
	        );

INSERT INTO level_4 (tot) VALUES (
(SELECT SUM(totalamount2011) AS tot11
	  FROM account
	  WHERE totalamount2011 >= 50000 AND totalamount2011 < 100000
	)
);

UPDATE level_4 
SET YEAR=2011
WHERE tot = ( SELECT SUM(totalamount2011) AS tot11
	  		  FROM account
	  		  WHERE totalamount2011 >= 50000 AND totalamount2011 < 100000
	        );
			
INSERT INTO level_4 (tot) VALUES (
(SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 50000 AND totalamount2012 < 100000
	)
);

UPDATE level_4 
SET YEAR=2012
WHERE tot = (SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 50000 AND totalamount2012 < 100000
);

INSERT INTO level_4 (tot) VALUES (
(SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 50000 AND totalamount2013 < 100000
	)
);

UPDATE level_4 
SET YEAR=2013
WHERE tot = (SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 50000 AND totalamount2013 < 100000
);
	
INSERT INTO level_4 (tot) VALUES (
(SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 50000 AND totalamount2014 < 100000
	)
);

UPDATE level_4 
SET YEAR=2014
WHERE tot = (SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 50000 AND totalamount2014 < 100000
);

INSERT INTO level_4 (tot) VALUES (
(SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 50000 AND totalamount2015 < 100000
	)
);

UPDATE level_4 
SET YEAR=2015
WHERE tot = (SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 50000 AND totalamount2015 < 100000
);

INSERT INTO level_4 (tot) VALUES (
(SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 50000 AND totalamount2016 < 100000
	)
);

UPDATE level_4 
SET YEAR=2016
WHERE tot = (SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 50000 AND totalamount2016 < 100000
);

/*level_5*/
CREATE TABLE level_5 
(
	year NUMERIC,
	tot NUMERIC
);

INSERT INTO level_5 (tot) VALUES (
(SELECT SUM(totalamount2010) AS tot10
	  FROM account
	  WHERE totalamount2010 >= 100000 AND totalamount2010 < 1000000
	)
);

UPDATE level_5 
SET YEAR=2010
WHERE tot = ( SELECT SUM(totalamount2010) AS tot10
	  		  FROM account
	  		  WHERE totalamount2010 >= 100000 AND totalamount2010 < 1000000
	        );

INSERT INTO level_5 (tot) VALUES (
(SELECT SUM(totalamount2011) AS tot11
	  FROM account
	  WHERE totalamount2011 >= 100000 AND totalamount2011 < 1000000
	)
);

UPDATE level_5 
SET YEAR=2011
WHERE tot = ( SELECT SUM(totalamount2011) AS tot11
	  		  FROM account
	  		  WHERE totalamount2011 >= 100000 AND totalamount2011 < 1000000
	        );
			
INSERT INTO level_5 (tot) VALUES (
(SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 100000 AND totalamount2012 < 1000000
	)
);

UPDATE level_5 
SET YEAR=2012
WHERE tot = (SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 100000 AND totalamount2012 < 1000000
);

INSERT INTO level_5 (tot) VALUES (
(SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 100000 AND totalamount2013 < 1000000
	)
);

UPDATE level_5 
SET YEAR=2013
WHERE tot = (SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 100000 AND totalamount2013 < 1000000
);
	
INSERT INTO level_5 (tot) VALUES (
(SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 100000 AND totalamount2014 < 1000000
	)
);

UPDATE level_5 
SET YEAR=2014
WHERE tot = (SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 100000 AND totalamount2014 < 1000000
);

INSERT INTO level_5 (tot) VALUES (
(SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 100000 AND totalamount2015 < 1000000
	)
);

UPDATE level_5 
SET YEAR=2015
WHERE tot = (SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 100000 AND totalamount2015 < 1000000
);

INSERT INTO level_5 (tot) VALUES (
(SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 100000 AND totalamount2016 < 1000000
	)
);

UPDATE level_5 
SET YEAR=2016
WHERE tot = (SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 100000 AND totalamount2016 < 1000000
);

UPDATE level_5
set year=2011, tot=0
WHERE year IS NULL AND tot IS NULL

/*level_6*/
CREATE TABLE level_6 
(
	id INT GENERATED ALWAYS AS IDENTITY,
	year NUMERIC,
	tot NUMERIC
);

INSERT INTO level_6 (tot) VALUES (
(SELECT SUM(totalamount2010) AS tot10
	  FROM account
	  WHERE totalamount2010 >= 1000000
	)
);

UPDATE level_6 
SET YEAR=2010
WHERE tot = ( SELECT SUM(totalamount2010) AS tot10
	  		  FROM account
	  		  WHERE totalamount2010 >= 1000000
	        );

INSERT INTO level_6 (tot) VALUES (
(SELECT SUM(totalamount2011) AS tot11
	  FROM account
	  WHERE totalamount2011 >= 1000000
	)
);

UPDATE level_6 
SET YEAR=2011
WHERE tot = ( SELECT SUM(totalamount2011) AS tot11
	  		  FROM account
	  		  WHERE totalamount2011 >= 1000000
	        );
			
INSERT INTO level_6 (tot) VALUES (
(SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 1000000
	)
);

UPDATE level_6 
SET YEAR=2012
WHERE tot = (SELECT SUM(totalamount2012) AS tot12
	  FROM account
	  WHERE totalamount2012 >= 1000000
);

INSERT INTO level_6 (tot) VALUES (
(SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 1000000
	)
);

UPDATE level_6 
SET YEAR=2013
WHERE tot = (SELECT SUM(totalamount2013) AS tot13
	  FROM account
	  WHERE totalamount2013 >= 1000000
);
	
INSERT INTO level_6 (tot) VALUES (
(SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 1000000
	)
);

UPDATE level_6 
SET YEAR=2014
WHERE tot = (SELECT SUM(totalamount2014) AS tot14
	  FROM account
	  WHERE totalamount2014 >= 1000000
);

INSERT INTO level_6 (tot) VALUES (
(SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 1000000
	)
);

UPDATE level_6 
SET YEAR=2015
WHERE tot = (SELECT SUM(totalamount2015) AS tot15
	  FROM account
	  WHERE totalamount2015 >= 1000000
);

INSERT INTO level_6 (tot) VALUES (
(SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 1000000
	)
);

UPDATE level_6 
SET YEAR=2016
WHERE tot = (SELECT SUM(totalamount2016) AS tot16
	  FROM account
	  WHERE totalamount2016 >= 1000000
);


UPDATE level_6
set year=2010, tot=0
WHERE id = 1;

UPDATE level_6
set year=2011, tot=0
WHERE id = 2;

UPDATE level_6
set year=2012, tot=0
WHERE id = 3;

UPDATE level_6
set year=2013, tot=0
WHERE id = 4;

UPDATE level_6
set year=2014, tot=0
WHERE id = 5;