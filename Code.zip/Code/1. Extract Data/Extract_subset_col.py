#this script extract a subset of columns from the two files.csv in the current folder
#and create 2 new files with the results

import pandas as pd

"""
#import data from accounts file using pandas
df = pd.read_csv('Rise Against Hunger - Accounts.csv',encoding='latin-1')

#first selections of data that can help to answer to business questions


Account_Number__c --> primary key
Account_Type__c
Account_Sub_Type__c
Id --Z foreign key linked to opporunities
BillingCity
BillingCountry
BillingPostalCode
BillingState
Assigned_To__c
Total_Giving__c
Total_Meals__c
Major_Donor__c
Num_of_Meals_2006__c
Num_of_Meals_2007__c
Num_of_Meals_2008__c
Num_of_Meals_2009__c
Num_of_Meals_2010__c
Num_of_Meals_2011__c
Num_of_Meals_2012__c
Num_of_Meals_2013__c
Num_of_Meals_2014__c
Num_of_Meals_2015__c
Num_of_Meals_2016__c
Total_Giving_2010__c
Total_Giving_2011__c
Total_Giving_2012__c
Total_Giving_2013__c
Total_Giving_2014__c
Total_Giving_2015__c
Total_Giving_2016__c

columns = ['Id', 'Account_Number__c', 'Account_Type__c', 'Account_Sub_Type__c',
           'BillingCity', 'BillingCountry', 'BillingPostalCode', 'BillingState',
           'Assigned_To__c', 'Total_Giving__c', 'Total_Meals__c', 'Major_Donor__c',
           'Num_of_Meals_2006__c', 'Num_of_Meals_2007__c', 'Num_of_Meals_2008__c',
           'Num_of_Meals_2009__c', 'Num_of_Meals_2010__c', 'Num_of_Meals_2011__c',
           'Num_of_Meals_2012__c', 'Num_of_Meals_2013__c', 'Num_of_Meals_2014__c',
           'Num_of_Meals_2015__c', 'Num_of_Meals_2016__c', 'Total_Giving_2010__c',
           'Total_Giving_2011__c', 'Total_Giving_2012__c', 'Total_Giving_2013__c',
           'Total_Giving_2014__c', 'Total_Giving_2015__c', 'Total_Giving_2016__c']

#Create a new DataFrame with subset of columns selected before
df1 = pd.DataFrame(df, columns = columns)

#Export subset of columns in csv
df1.to_csv("Accounts.csv", header=True)
"""
###################################################################################################
###################################################################################################

#import data from opporunities file using pandas
df = pd.read_csv('Rise Against Hunger - Opportunities.csv',encoding='latin-1')

#first selections of data that can help to answer to business questions
"""
AccountId --> foreign key of Opportunities linked to Id Accounts table
CampaignId
Campaign_Name__c
rC_Giving__Giving_Frequency__c
"""

columns = ['AccountId', 'CampaignId',
           'Campaign_Name__c', 'rC_Giving__Giving_Frequency__c', 'Type']
           
#Create a new DataFrame with subset of columns selected before
df1 = pd.DataFrame(df, columns = columns)

#Export subset of columns in csv
df1.to_csv("Opportunities.csv", header=True)