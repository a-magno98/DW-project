SET search_path TO 'project';

CREATE TABLE year_dt (
			yearid INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
			year   NUMERIC NOT NULL
);

CREATE TABLE assigned_dt (
			assignedid INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
			assigned  VARCHAR NOT NULL
);

CREATE TABLE account_dt (
			accountid INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
			accountnumber VARCHAR NOT NULL,
			majordonor	  BOOLEAN NOT NULL,
			type 		  VARCHAR NOT NULL,
			subtype		  VARCHAR NOT NULL,
			postalcode 	  NUMERIC NOT NULL,
			city		  VARCHAR NOT NULL,
			state		  VARCHAR NOT NULL,
			country 	  VARCHAR NOT NULL
);

CREATE TABLE donation_ft (
	accountid INT NOT NULL,    
	assignedid INT NOT NULL,
	yearid INT NOT NULL,
	totalamount NUMERIC,
	num_meals NUMERIC
);

/* dati da inserire*/
INSERT INTO year_dt(year) VALUES ('2006');
INSERT INTO year_dt(year) VALUES ('2007');
INSERT INTO year_dt(year) VALUES ('2008');
INSERT INTO year_dt(year) VALUES ('2009');
INSERT INTO year_dt(year) VALUES ('2010');
INSERT INTO year_dt(year) VALUES ('2011');
INSERT INTO year_dt(year) VALUES ('2012');
INSERT INTO year_dt(year) VALUES ('2013');
INSERT INTO year_dt(year) VALUES ('2014');
INSERT INTO year_dt(year) VALUES ('2015');
INSERT INTO year_dt(year) VALUES ('2016');

INSERT INTO assigned_dt(assigned) (SELECT DISTINCT(assigned) FROM account);

INSERT INTO account_dt(accountnumber, majordonor, type, subtype, postalcode, city, state, country)
(SELECT number, majordonor, type, subtype, postalcode, city, state, country FROM account);

/******************************************************************************************************/
CREATE TABLE temp as (
select number, assigned, nummeals2006 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2006',
ADD totalamount NUMERIC DEFAULT NULL;

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount,nummeals2006
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2007 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2007',
ADD totalamount NUMERIC DEFAULT NULL;

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount,nummeals2007
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);
 
drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2008 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2008',
ADD totalamount NUMERIC DEFAULT NULL;

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount,nummeals2008
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2009 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2009',
ADD totalamount NUMERIC DEFAULT NULL;

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount,nummeals2009
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2010, totalamount2010 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2010';

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount2010,nummeals2010
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2011, totalamount2011 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2011';

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount2011,nummeals2011
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2012, totalamount2012 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2012';

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount2012,nummeals2012
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2013, totalamount2013 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2013';

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount2013,nummeals2013
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2014, totalamount2014 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2014';

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount2014,nummeals2014
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2015, totalamount2015 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2015';

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount2015,nummeals2015
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


CREATE TABLE temp as (
select number, assigned, nummeals2016, totalamount2016 from account);

ALTER TABLE temp
ADD year NUMERIC NOT NULL DEFAULT '2016';

INSERT INTO donation_ft(accountid,assignedid,yearid,totalamount,num_meals)
(SELECT accountid, assignedid,yearid,totalamount2016,nummeals2016
 FROM temp T, account_dt acc, year_dt as Y, assigned_dt as ass
 WHERE T.year = Y.year and T.assigned = ass.assigned and T.number = acc.accountnumber);

drop table temp;


ALTER TABLE ONLY donation_ft
    ADD CONSTRAINT primary_donation PRIMARY KEY (accountid,assignedid,yearid);

ALTER TABLE ONLY donation_ft
    ADD CONSTRAINT donation_time FOREIGN KEY (yearid) REFERENCES year_dt(yearid) ON DELETE CASCADE;
	
ALTER TABLE ONLY donation_ft
    ADD CONSTRAINT donation_assigned FOREIGN KEY (assignedid) REFERENCES assigned_dt(assignedid) ON DELETE CASCADE;
	
ALTER TABLE ONLY donation_ft
    ADD CONSTRAINT donation_account FOREIGN KEY (accountid) REFERENCES account_dt(accountid) ON DELETE CASCADE;